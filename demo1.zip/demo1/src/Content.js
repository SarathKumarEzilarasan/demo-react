import React from "react";
import { useState } from "react";

const Content = () => {
  function randomName() {
    const names = ["John", "Peter"];
    const i = Math.floor(Math.random() * 2);
    return names[i];
  }

  const [count, setCount] = useState(99);

  const [name, setName] = useState({ a: "john" });

  function display() {
    console.log("hello world");
  }

  function incrementFunc() {
    setCount(count + 1);
    setCount((count) => count + 1);
  }

  function decrementFunc() {
    setCount((count) => count - 1);
  }

  return (
    <main>
      <p>Logged in by {randomName()}</p>
      <button onClick={decrementFunc}>-</button>
      <span>{count}</span>
      <button onClick={incrementFunc}>+</button>
    </main>
  );
};

export default Content;
