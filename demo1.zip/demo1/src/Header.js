import React from "react";

const Header = () => {
  const headerStyle = { backgroundColor: "blue" };
  return (
    <header style={{ backgroundColor: "blue" }}>
      <h1>To do List</h1>
    </header>
  );
};

export default Header;
