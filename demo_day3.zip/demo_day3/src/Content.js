import React from "react";
import ItemList from "./ItemList";

const Content = ({ items, setItems, handleCheck, deleteTask }) => {
  return (
    <>
      {items.length ? (
        <ItemList
          items={items}
          setItems={setItems}
          handleCheck={handleCheck}
          deleteTask={deleteTask}
        />
      ) : (
        <p style={{ marginTop: "25px" }}>List is Empty</p>
      )}
    </>
  );
};

export default Content;
