import React from "react";

const Header = ({ title }) => {
  const headerStyle = { backgroundColor: "blue" };
  return (
    <header style={{ backgroundColor: "blue" }}>
      <h1>{title}</h1>
    </header>
  );
};

Header.defaultProps = {
  title: "To Do from Header",
};

export default Header;
