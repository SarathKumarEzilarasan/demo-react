const url = "http://localhost:8080/db";

const get = async () => {
  const response = await fetch(url);

  const respBody = await response.json();
  console.log(respBody[0]);
};

get();
