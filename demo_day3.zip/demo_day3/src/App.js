import "./App.css";
import Content from "./Content";
import Header from "./Header";
import Footer from "./Footer";
import AddItem from "./AddItem";
import SearchItem from "./SearchItem";
import { useEffect, useState } from "react";
import apiRequest from "./apiRequests";

function App() {
  const API_URL = "http://localhost:8080/db/";

  // const [items, setItems] = useState([
  //   { id: 1, checked: true, description: "Java" },
  //   { id: 2, checked: false, description: "JS" },
  //   { id: 3, checked: true, description: "Spring" },
  // ]);
  const [items, setItems] = useState(
    JSON.parse(localStorage.getItem("todo_list")) || []
  );

  console.log("before");
  const [newItem, setNewItem] = useState();
  const [isError, setIsError] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchItems = async () => {
      try {
        const response = await apiRequest(API_URL);
        const respBody = await response.json();
        setItems(respBody);
      } catch (err) {
        setIsError(err.message);
      } finally {
        setIsLoading(false);
      }
    };
    fetchItems();
    console.log(isError);
  }, []);

  console.log("after");
  const handleCheck = (id) => {
    let listItems = items.map((item) =>
      item.id === id ? { ...item, checked: !item.checked } : item
    );
    setItems(listItems);
    localStorage.setItem("todo_list", JSON.stringify(listItems));
  };

  const deleteTask = (id) => {
    let listItems = items.filter((item) => item.id !== id);
    setItems(listItems);
    localStorage.setItem("todo_list", JSON.stringify(listItems));
  };

  const addTask = async (item) => {
    const id = items.length ? items[items.length - 1].id + 1 : 1;

    const addNewTask = { id: id, checked: false, description: item };
    const listItems = [...items, addNewTask];

    setItems(listItems);

    const postOptions = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(addNewTask),
    };
    try {
      const response = await apiRequest(API_URL + item.id, postOptions);
    } catch (err) {
      setIsError(err.message);
    }
  };

  const [searchItem, setSearchItem] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(newItem);
    addTask(newItem);
    setNewItem("");
  };

  return (
    <div className="App">
      <Header title="To do List" />
      <AddItem
        newItem={newItem}
        setNewItem={setNewItem}
        handleSubmit={handleSubmit}
      />
      <SearchItem searchItem={searchItem} setSearchItem={setSearchItem} />
      <main>
        {isError && <p>Error while loading the items</p>}
        {isLoading && <p>Loading Item</p>}
        {!isError && !isLoading && (
          <Content
            items={items.filter((item) =>
              item.description.toLowerCase().includes(searchItem.toLowerCase())
            )}
            setItems={setItems}
            handleCheck={handleCheck}
            deleteTask={deleteTask}
          />
        )}
      </main>
      <Footer length={items.length} />
    </div>
  );
}

export default App;

//router ---
//redux
