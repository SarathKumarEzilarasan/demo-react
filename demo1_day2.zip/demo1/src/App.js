import "./App.css";
import Content from "./Content";
import Header from "./Header";
import Footer from "./Footer";
import AddItem from "./AddItem";
import SearchItem from "./SearchItem";
import { useState } from "react";

function App() {
  // const [items, setItems] = useState([
  //   { id: 1, checked: true, description: "Java" },
  //   { id: 2, checked: false, description: "JS" },
  //   { id: 3, checked: true, description: "Spring" },
  // ]);
  const [items, setItems] = useState(
    JSON.parse(localStorage.getItem("todo_list"))
  );

  const handleCheck = (id) => {
    let listItems = items.map((item) =>
      item.id === id ? { ...item, checked: !item.checked } : item
    );
    setItems(listItems);
    localStorage.setItem("todo_list", JSON.stringify(listItems));
  };

  const deleteTask = (id) => {
    let listItems = items.filter((item) => item.id !== id);
    setItems(listItems);
    localStorage.setItem("todo_list", JSON.stringify(listItems));
  };

  const [newItem, setNewItem] = useState();

  const addTask = (item) => {
    const id = items.length ? items[items.length - 1].id + 1 : 1;

    const addNewTask = { id: id, checked: false, description: item };
    const listItems = [...items, addNewTask];

    setItems(listItems);
    localStorage.setItem("todo_list", JSON.stringify(listItems));
  };

  const [searchItem, setSearchItem] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(newItem);
    addTask(newItem);
    setNewItem("");
  };

  return (
    <div className="App">
      <Header title="To do List" />
      <AddItem
        newItem={newItem}
        setNewItem={setNewItem}
        handleSubmit={handleSubmit}
      />
      <SearchItem searchItem={searchItem} setSearchItem={setSearchItem} />
      <Content
        items={items.filter((item) =>
          item.description.toLowerCase().includes(searchItem.toLowerCase())
        )}
        setItems={setItems}
        handleCheck={handleCheck}
        deleteTask={deleteTask}
      />
      <Footer length={items.length} />
    </div>
  );
}

export default App;
