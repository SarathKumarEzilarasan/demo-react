import React from "react";

const SearchItem = ({ searchItem, setSearchItem }) => {
  return (
    <form className="searchForm">
      <label htmlFor="">Search</label>
      <input
        id="search"
        type="text"
        required
        placeholder="Search Items"
        value={searchItem}
        onChange={(e) => setSearchItem(e.target.value)}
      />
    </form>
  );
};

export default SearchItem;
